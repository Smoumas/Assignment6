import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Random;

import javax.mail.MessagingException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

/**
 * Register���ṩע���û��Ĺ���
 * @author user1
 *
 */
public class Register {
	
	private Customer customer;
	private JFrame jf;
	private JLabel IDLabel;		
	private JTextField IDText;	
	private JLabel accountLabel;	
	private JTextField accountText;
	private JLabel passwordLabel;
	private JPasswordField passwordText;
	private JLabel nameLabel;
	private JTextField nameText;
	private JLabel sexLabel;
	private JTextField sexText;
	private JLabel phoneLabel;
	private JTextField phoneText;
	private JLabel addressLabel;
	private JTextField addressText;
	private JLabel emailLabel;
	private JTextField emailText;
	private JLabel captchaLabel;
	private JTextField captchaText;
	private JButton captchaButton;
	private JButton button;
	private JButton button2;
	private int captcha=0;
	
	public Register(){
		customer=new Customer();
		jf=new JFrame("ע�����û�");
		jf.setBounds(480,130,400,480);
		jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		jf.setLayout(null);
		IDInit();
		accountInit();
		passwordInit();
		nameInit();
		sexInit();
		phoneInit();
		addressInit();
		emailInit();
		captchaInit();
		registerButtonInit();
		cancelButtonInit();
		jf.setVisible(true);
	}
	
	private void IDInit(){
		IDLabel=new JLabel("ID:");
		IDLabel.setSize(100,20);
		IDLabel.setLocation(70,30);
		jf.add(IDLabel);
		IDText=new JTextField();
		IDText.setSize(200,20);
		IDText.setLocation(120,30);
		jf.add(IDText);
		return;
	}
	private void accountInit(){
		accountLabel=new JLabel("Account:");
		accountLabel.setSize(100,20);
		accountLabel.setLocation(50,70);
		jf.add(accountLabel);
		accountText=new JTextField();
		accountText.setSize(200,20);
		accountText.setLocation(120,70);
		jf.add(accountText);
		return;
	}
	private void passwordInit(){
		passwordLabel=new JLabel("Password:");
		passwordLabel.setSize(100,20);
		passwordLabel.setLocation(43,110);
		jf.add(passwordLabel);
		passwordText=new JPasswordField();
		passwordText.setSize(200,20);
		passwordText.setLocation(120,110);
		jf.add(passwordText);
	}
	private void nameInit(){
		nameLabel=new JLabel("Name:");
		nameLabel.setSize(100,20);
		nameLabel.setLocation(55,150);
		jf.add(nameLabel);
		nameText=new JTextField();
		nameText.setSize(200,20);
		nameText.setLocation(120,150);
		jf.add(nameText);
		return;
	}
	private void sexInit(){
		sexLabel=new JLabel("Sex:");
		sexLabel.setSize(100,20);
		sexLabel.setLocation(60,190);
		jf.add(sexLabel);
		sexText=new JTextField();
		sexText.setSize(200,20);
		sexText.setLocation(120,190);
		jf.add(sexText);
		return;
	}
	private void phoneInit(){
		phoneLabel=new JLabel("Phone:");
		phoneLabel.setSize(100,20);
		phoneLabel.setLocation(53,230);
		jf.add(phoneLabel);
		phoneText=new JTextField();
		phoneText.setSize(200,20);
		phoneText.setLocation(120,230);
		jf.add(phoneText);
		return;
	}
	private void addressInit(){
		addressLabel=new JLabel("Address:");
		addressLabel.setSize(100,20);
		addressLabel.setLocation(50,270);
		jf.add(addressLabel);
		addressText=new JTextField();
		addressText.setSize(200,20);
		addressText.setLocation(120,270);
		jf.add(addressText);
		return;
	}
	private void emailInit(){
		emailLabel=new JLabel("Email:");
		emailLabel.setSize(100,20);
		emailLabel.setLocation(55,310);
		jf.add(emailLabel);
		emailText=new JTextField();
		emailText.setSize(200,20);
		emailText.setLocation(120,310);
		jf.add(emailText);
		return;
	}
	private void captchaInit(){
		captchaLabel=new JLabel("Captcha:");
		captchaLabel.setSize(100,20);
		captchaLabel.setLocation(50,350);
		jf.add(captchaLabel);
		captchaText=new JTextField();
		captchaText.setSize(60,20);
		captchaText.setLocation(120,350);
		jf.add(captchaText);
		captchaText.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e){
				int code=e.getKeyCode();
				if(code==KeyEvent.VK_ENTER){
					register();
				}
			}
		});
		captchaButton=new JButton("Get Captcha");
		captchaButton.setSize(120,20);
		captchaButton.setLocation(200,350);
		captchaButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				//����������������ɸѡ
				String regex="(\\w+)@\\w+(\\.\\w+)+";
				if(!emailText.getText().matches(regex)){
					JOptionPane.showMessageDialog(null,"��������ȷ������");
					return;
				}
				//�����������������֤��
				Random random=new Random();
				captcha=random.nextInt(10000)%(10000-1000)+1000;
				try {
					new MailSender("smtp.aliyun.com","Smoumas@aliyun.com","Smoumas0129").send(emailText.getText(),"Captcha",captcha);
				} catch (MessagingException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				};
			}
		});
		jf.add(captchaButton);
	}
	private void registerButtonInit(){
		button=new JButton("Register");
		button.setSize(100,20);
		button.setLocation(70,390);
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				register();
			}
		});
		jf.add(button);
		return;
	}
	private void cancelButtonInit(){
		button2=new JButton("Cancel");
		button2.setSize(100,20);
		button2.setLocation(220,390);
		button2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				jf.dispose();
			}
		});
		jf.add(button2);
		return;
	}
	/**
	 * registe()�����ṩע�Ṧ��
	 */
	private void register(){
		String ID=IDText.getText();
		String account=accountText.getText();
		String password=new String(passwordText.getPassword());
		String name=nameText.getText();
		String sex=sexText.getText();
		String phone=phoneText.getText();
		String address=addressText.getText();
		String email=emailText.getText();
		String userCaptcha=captchaText.getText();
		if(ID.equals("")){
			JOptionPane.showMessageDialog(null,"ID����Ϊ��");
			return;
		}
		if(account.equals("")){
			JOptionPane.showMessageDialog(null,"�˺Ų���Ϊ��");
			return;
		}
		if(password.equals("")){
			JOptionPane.showMessageDialog(null,"���벻��Ϊ��");
			return;
		}
		if(name.equals("")){
			JOptionPane.showMessageDialog(null,"��������Ϊ��");
			return;
		}
		if(sex.equals("")){
			JOptionPane.showMessageDialog(null,"�Ա���Ϊ��");
			return;
		}
		if(phone.equals("")){
			JOptionPane.showMessageDialog(null,"�绰����Ϊ��");
			return;
		}
		if(address.equals("")){
			JOptionPane.showMessageDialog(null,"��ַ����Ϊ��");
			return;
		}
		if(email.equals("")){
			JOptionPane.showMessageDialog(null,"Email����Ϊ��");
		}
		if(!isPhoneNumber(phone)){
			JOptionPane.showMessageDialog(null,"��������ȷ�ĵ绰����");
			return;
		}
		if(!email.matches("(\\w+)@\\w+(\\.\\w+)+")){
			JOptionPane.showMessageDialog(null,"��������ȷ������");
			return;
		}
		if(!userCaptcha.equals(captcha+"")){
			JOptionPane.showMessageDialog(null,"��֤�����");
			return;
		}
		customer.setID(ID);
		customer.setAccount(account);
		customer.setPassword(password);
		customer.setName(name);
		customer.setSex(sex);
		customer.setPhone(phone);
		customer.setAddress(address);
		customer.setEmail(email);
		//��Properties���û�������txt����ʽд��Ӳ��
		File file=new File(account+".txt");
		if(file.exists()){
			JOptionPane.showMessageDialog(null,"���û��Ѵ���");
			return;
		}
		FileOutputStream fos=null;
		try {
			fos=new FileOutputStream(account+".txt");
			Properties prop=new Properties();
			prop.setProperty("ID",ID);
			prop.setProperty("account",account);
			prop.setProperty("password",password);
			prop.setProperty("name",name);
			prop.setProperty("sex",sex);
			prop.setProperty("phone",phone);
			prop.setProperty("address",address);
			prop.setProperty("email",email);
			prop.store(fos,null);
			jf.dispose();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return;
	}
	/**
	 * isPhoneNumber()���������ж��û�������Ƿ��ǵ绰����
	 * @param str
	 * @return
	 */
	private boolean isPhoneNumber(String str){
		String regex = "1[3578]\\d{9}"; 
		return str.matches(regex);
	}
}
