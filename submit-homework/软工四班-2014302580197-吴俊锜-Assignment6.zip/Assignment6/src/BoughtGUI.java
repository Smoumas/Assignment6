import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;
/**
 * 
 * @author user1
 *
 */
public class BoughtGUI {
	private Customer customer;
	private JFrame jf;
	private JLabel goodsLabel;
	private JLabel numbersLabel;
	private JLabel totalLabel;
	private int total;		//�û�����������Ʒ���ܼ�
	
	public BoughtGUI(Customer customer){
		this.customer=customer;
		jf=new JFrame("Bought");
		jf.setBounds(500,200,300,380);
		jf.setLayout(null);
		jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		headInit();
		boughtInit();
		jf.setVisible(true);
	}
	public void headInit(){
		goodsLabel=new JLabel("Goods");
		goodsLabel.setSize(100,20);
		goodsLabel.setLocation(60,20);
		jf.add(goodsLabel);
		numbersLabel=new JLabel("Number");
		numbersLabel.setSize(100,20);
		numbersLabel.setLocation(160,20);
		jf.add(numbersLabel);
		total=0;
		totalLabel=new JLabel("Total:$"+String.valueOf(total));
		totalLabel.setSize(100,20);
		totalLabel.setLocation(60,300);
		jf.add(totalLabel);
	}
	public void boughtInit(){
		Properties boughtProp=new Properties();
		//�û��ѹ���û��Ʒ����ʾnone��totalΪ0
		File file=new File(customer.getAccount()+"Bought.txt");
		if(!file.exists()){
			JLabel goodLabel=new JLabel("none");
			goodLabel.setSize(100,20);
			goodLabel.setLocation(60,40);
			JLabel numberLabel=new JLabel("none");
			numberLabel.setSize(100,20);
			numberLabel.setLocation(170,40);
			jf.add(goodLabel);
			jf.add(numberLabel);
			return;
		}
		BufferedReader bufr=null;
		try {
			bufr=new BufferedReader(new FileReader(file));
			boughtProp.load(bufr);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				bufr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(boughtProp.size()==0){
			JLabel goodLabel=new JLabel("none");
			goodLabel.setSize(100,20);
			goodLabel.setLocation(60,60);
			JLabel numberLabel=new JLabel("none");
			numberLabel.setSize(100,20);
			numberLabel.setLocation(170,60);
			jf.add(goodLabel);
			jf.add(numberLabel);
			return;
		}
		//��ȡBought�ļ�������ʾ���ѹ����Pet������
		Set<Object> keys=boughtProp.keySet();
		Iterator<Object>it=keys.iterator();
		int len=0;
		while(it.hasNext()){
			String good=(String) it.next();
			String number=boughtProp.getProperty(good);
			JLabel goodLabel=new JLabel(good);
			goodLabel.setLocation(60,40+20*len);
			goodLabel.setSize(100,20);
			jf.add(goodLabel);
			JLabel numberLabel=new JLabel(number);
			numberLabel.setLocation(170,40+20*len);
			numberLabel.setSize(100,20);
			jf.add(numberLabel);
			total=total+Integer.parseInt(numberLabel.getText());
			totalLabel.setText("Total:$"+total);
			len++;
		}
	}
}
