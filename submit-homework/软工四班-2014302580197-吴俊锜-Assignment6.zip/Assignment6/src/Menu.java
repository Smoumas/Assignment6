import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

/**
 * Menu���ṩ���˵���GUI
 * @author user1
 *
 */
public class Menu {
	private JFrame jf;
	private JLabel headLabel;
	private JButton logoutButton;
	private JButton cartButton;
	private JButton boughtButton;
	private JLabel nameLabel1;
	private JLabel eatLabel1;
	private JLabel drinkLabel1;
	private JLabel liveLabel1;
	private JLabel hobbyLabel1;
	private JLabel priceLabel1;
	private JButton addButton1;
	private JLabel nameLabel2;
	private JLabel eatLabel2;
	private JLabel drinkLabel2;
	private JLabel liveLabel2;
	private JLabel hobbyLabel2;
	private JLabel priceLabel2;
	private JButton addButton2;
	private JLabel nameLabel3;
	private JLabel eatLabel3;
	private JLabel drinkLabel3;
	private JLabel liveLabel3;
	private JLabel hobbyLabel3;
	private JLabel priceLabel3;
	private JButton addButton3;
	private JButton previousButton;
	private JButton nextButton;
	private JButton firstButton;
	private JButton lastButton;
	private int pageCount=1;
	private Database database;
	private Pet[] pets;
	private Customer customer;
	private JTextField searchTextField;
	private JButton searchButton;
	
	public Menu(Customer customer){
		this.customer=customer;
		jf=new JFrame("Menu");
		jf.setBounds(350,150,580,450);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		jf.setLayout(null);
		databaseInit();
		headInit(customer.getName());
		contentInit();
		jf.setVisible(true);
	}
	/**
	 * databaseInit()���������ݿ��л�ȡPet
	 */
	private void databaseInit(){
		database=new Database();
		database.getPets();
		pets=database.getPetArray();
	}
	private void headInit(String name){
		headLabel=new JLabel("Welcom,"+name);
		headLabel.setSize(120+name.length(),20);
		headLabel.setLocation(20,20);
		jf.add(headLabel);
		logoutButton=new JButton("Logout");
		logoutButton.setSize(80,18);
		logoutButton.setLocation(280,20);
		//�����û�ע���¼�
		logoutButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Login();
				jf.dispose();
			}
		});
		jf.add(logoutButton);
		cartButton=new JButton("Cart");
		cartButton.setSize(80,18);
		cartButton.setLocation(380,20);
		//���ﳵ
		cartButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new CartGUI(customer);
			}
		});
		jf.add(cartButton);
		boughtButton=new JButton("Bought");
		boughtButton.setSize(80,18);
		boughtButton.setLocation(480,20);
		//�ѹ���
		boughtButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new BoughtGUI(customer);
			}
		});
		jf.add(boughtButton);
	}
	
	private void contentInit(){
		//searchģ��
		searchTextField=new JTextField();
		searchTextField.setSize(180,20);
		searchTextField.setLocation(280,50);
		searchTextField.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e){
				int code=e.getKeyCode();
				if(code==KeyEvent.VK_ENTER){
					String content=searchTextField.getText();
					content=content.trim();
					content=content.replaceAll(" ","");
					content=content.toLowerCase();
					Pet pet=null;
					for(int i=0;i<12;i++){
						if(pets[i].getName().equals(content)){
							pet=pets[i];
							break;
						}
					}
					if(pet==null){
						JOptionPane.showMessageDialog(null,"û�и����Ƶĳ���");
						return;
					}
					showSearchResult(pet);
					searchTextField.setText("");
				}
			}
		});
		jf.add(searchTextField);
		searchButton=new JButton("Search");
		searchButton.setSize(80,20);
		searchButton.setLocation(480,50);
		searchButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String content=searchTextField.getText();
				content=content.trim();
				content=content.replaceAll(" ","");
				content=content.toLowerCase();
				Pet pet=null;
				for(int i=0;i<12;i++){
					if(pets[i].getName().equals(content)){
						pet=pets[i];
						break;
					}
				}
				if(pet==null){
					JOptionPane.showMessageDialog(null,"û�и����Ƶĳ���");
					return;
				}
				showSearchResult(pet);
				searchTextField.setText("");
			}
		});
		jf.add(searchButton);
		showGood1(pets[0]);		//�����Ʒ
		showGood2(pets[1]);		//�м���Ʒ
		showGood3(pets[2]);		//�Ҳ���Ʒ
		preAndNextInit();		//��һҳ����һҳ��ť
		firstAndLastInit();		//��ҳ��ĩҳ��ť
	}
	/**
	 * չʾ�����Ʒ
	 * @param pet
	 */
	private void showGood1(Pet pet){
		nameLabel1=new JLabel(pet.getName().toUpperCase());
		eatLabel1=new JLabel("Eat:"+pet.getEat());
		drinkLabel1=new JLabel("Drink:"+pet.getDrink());
		liveLabel1=new JLabel("Live:"+pet.getLive());
		hobbyLabel1=new JLabel("Hobby:"+pet.getHobby());
		priceLabel1=new JLabel("Price:$1.00");
		addButton1=new JButton("Add to Cart");
		nameLabel1.setLocation(60,80);
		nameLabel1.setSize(100,20);
		eatLabel1.setLocation(60,120);
		eatLabel1.setSize(180,20);
		drinkLabel1.setLocation(60,160);
		drinkLabel1.setSize(100,20);
		liveLabel1.setLocation(60,200);
		liveLabel1.setSize(180,20);
		hobbyLabel1.setLocation(60,240);
		hobbyLabel1.setSize(100,20);
		priceLabel1.setLocation(60,270);
		priceLabel1.setSize(100,20);
		addButton1.setLocation(50,300);
		addButton1.setSize(100,20);
		addButton1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Pet pet=pets[0+3*(pageCount-1)];
				customer.getCart().add(pet);
				JOptionPane.showMessageDialog(null,"�ѳɹ����ӵ����ﳵ");
			}
		});
		jf.add(nameLabel1);
		jf.add(eatLabel1);
		jf.add(drinkLabel1);
		jf.add(liveLabel1);
		jf.add(hobbyLabel1);
		jf.add(priceLabel1);
		jf.add(addButton1);
	}
	/**
	 * չʾ�м���Ʒ
	 * @param pet
	 */
	private void showGood2(Pet pet){
		nameLabel2=new JLabel(pet.getName().toUpperCase());
		eatLabel2=new JLabel("Eat:"+pet.getEat());
		drinkLabel2=new JLabel("Drink:"+pet.getDrink());
		liveLabel2=new JLabel("Live:"+pet.getLive());
		hobbyLabel2=new JLabel("Hobby:"+pet.getHobby());
		addButton2=new JButton("Add to Cart");
		nameLabel2.setLocation(220,80);
		nameLabel2.setSize(100,20);
		eatLabel2.setLocation(220,120);
		eatLabel2.setSize(180,20);
		drinkLabel2.setLocation(220,160);
		drinkLabel2.setSize(100,20);
		liveLabel2.setLocation(220,200);
		liveLabel2.setSize(180,20);
		hobbyLabel2.setLocation(220,240);
		hobbyLabel2.setSize(100,20);
		priceLabel2=new JLabel("Price:$1.00");
		priceLabel2.setLocation(220,270);
		priceLabel2.setSize(100,20);
		addButton2.setLocation(210,300);
		addButton2.setSize(100,20);
		addButton2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Pet pet=pets[1+3*(pageCount-1)];
				customer.getCart().add(pet);
				JOptionPane.showMessageDialog(null,"�ѳɹ����ӵ����ﳵ");
			}
		});
		jf.add(nameLabel2);
		jf.add(eatLabel2);
		jf.add(drinkLabel2);
		jf.add(liveLabel2);
		jf.add(hobbyLabel2);
		jf.add(priceLabel2);
		jf.add(addButton2);
	}
	
	/**
	 * չʾ�Ҳ���Ʒ
	 * @param pet
	 */
	private void showGood3(Pet pet){
		nameLabel3=new JLabel(pet.getName().toUpperCase());
		eatLabel3=new JLabel("Eat:"+pet.getEat());
		drinkLabel3=new JLabel("Drink:"+pet.getDrink());
		liveLabel3=new JLabel("Live:"+pet.getLive());
		hobbyLabel3=new JLabel("Hobby:"+pet.getHobby());
		addButton3=new JButton("Add to Cart");
		nameLabel3.setLocation(360,80);
		nameLabel3.setSize(100,20);
		eatLabel3.setLocation(360,120);
		eatLabel3.setSize(180,20);
		drinkLabel3.setLocation(360,160);
		drinkLabel3.setSize(100,20);
		liveLabel3.setLocation(360,200);
		liveLabel3.setSize(180,20);
		hobbyLabel3.setLocation(360,240);
		hobbyLabel3.setSize(100,20);
		priceLabel3=new JLabel("Price:$1.00");
		priceLabel3.setLocation(360,270);
		priceLabel3.setSize(100,20);
		addButton3.setLocation(350,300);
		addButton3.setSize(100,20);
		addButton3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Pet pet=pets[2+3*(pageCount-1)];
				customer.getCart().add(pet);
				JOptionPane.showMessageDialog(null,"�ѳɹ����ӵ����ﳵ");
			}
		});
		jf.add(nameLabel3);
		jf.add(eatLabel3);
		jf.add(drinkLabel3);
		jf.add(liveLabel3);
		jf.add(hobbyLabel3);
		jf.add(priceLabel3);
		jf.add(addButton3);
	}
	/**
	 * ��һҳ����һҳ��ť
	 */
	private void preAndNextInit(){
		previousButton=new JButton("Previous");
		previousButton.setLocation(140,350);
		previousButton.setSize(100,20);
		previousButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clearContent();
				showGood1(pets[0+(pageCount-2)*3]);
				showGood2(pets[1+(pageCount-2)*3]);
				showGood3(pets[2+(pageCount-2)*3]);
				pageCount--;
				//��Ϊ��һҳ�������һҳ����һҳ��ťʧЧ
				if(pageCount==1){
					previousButton.setEnabled(false);
					firstButton.setEnabled(false);
				}
				nextButton.setEnabled(true);
				lastButton.setEnabled(true);
			}
		});
		previousButton.setEnabled(false);
		jf.add(previousButton);
		nextButton=new JButton("Next");
		nextButton.setLocation(280,350);
		nextButton.setSize(100,20);
		nextButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clearContent();
				showGood1(pets[0+pageCount*3]);
				showGood2(pets[1+pageCount*3]);
				showGood3(pets[2+pageCount*3]);
				pageCount++;
				//��Ϊĩҳ������ĩҳ��ť����һҳ��ťʧЧ
				if(pageCount==4){
					nextButton.setEnabled(false);
					lastButton.setEnabled(false);
				}
				previousButton.setEnabled(true);
				firstButton.setEnabled(true);
			}
		});
		jf.add(nextButton);
	}
	/**
	 * ��ҳ��ĩҳ��ť
	 */
	private void firstAndLastInit(){
		firstButton=new JButton("First");
		firstButton.setLocation(140,380);
		firstButton.setSize(100,20);
		firstButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clearContent();
				pageCount=1;
				showGood1(pets[0]);
				showGood2(pets[1]);
				showGood3(pets[2]);
				firstButton.setEnabled(false);
				previousButton.setEnabled(false);
				lastButton.setEnabled(true);
				nextButton.setEnabled(true);
			}
		});
		firstButton.setEnabled(false);
		jf.add(firstButton);
		lastButton=new JButton("Last");
		lastButton.setLocation(280,380);
		lastButton.setSize(100,20);
		lastButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				clearContent();
				pageCount=4;
				showGood1(pets[9]);
				showGood2(pets[10]);
				showGood3(pets[11]);
				lastButton.setEnabled(false);
				nextButton.setEnabled(false);
				firstButton.setEnabled(true);
				previousButton.setEnabled(true);
			}
		});
		jf.add(lastButton);
	}
	//���Ŀǰչʾ������Ʒ
	private void clearContent(){
		nameLabel1.setText("");
		eatLabel1.setText("");
		drinkLabel1.setText("");
		liveLabel1.setText("");
		hobbyLabel1.setText("");
		nameLabel2.setText("");
		eatLabel2.setText("");
		drinkLabel2.setText("");
		liveLabel2.setText("");
		hobbyLabel2.setText("");
		nameLabel3.setText("");
		eatLabel3.setText("");
		drinkLabel3.setText("");
		liveLabel3.setText("");
		hobbyLabel3.setText("");
	}
	/**
	 * ���´���չʾ�������
	 * @param pet
	 */
	private void showSearchResult(Pet pet){
		JFrame jf=new JFrame("Search Result");
		jf.setBounds(500,220,300,320);
		jf.setLayout(null);
		jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		JLabel nameLabel=new JLabel(pet.getName().toUpperCase());
		JLabel eatLabel=new JLabel("Eat:"+pet.getEat());
		JLabel drinkLabel=new JLabel("Drink:"+pet.getDrink());
		JLabel liveLabel=new JLabel("Live:"+pet.getLive());
		JLabel hobbyLabel=new JLabel("Hobby:"+pet.getHobby());
		JLabel priceLabel=new JLabel("Price:$1.00");
		JButton addButton=new JButton("Add to Cart");
		nameLabel.setSize(100,20);
		nameLabel.setLocation(30,10);
		jf.add(nameLabel);
		eatLabel.setSize(180,20);
		eatLabel.setLocation(30,50);
		jf.add(eatLabel);
		drinkLabel.setSize(100,20);
		drinkLabel.setLocation(30,90);
		jf.add(drinkLabel);
		liveLabel.setSize(180,20);
		liveLabel.setLocation(30,130);
		jf.add(liveLabel);
		hobbyLabel.setSize(100,20);
		hobbyLabel.setLocation(30,170);
		jf.add(hobbyLabel);
		priceLabel.setSize(100,20);
		priceLabel.setLocation(30,210);
		jf.add(priceLabel);
		addButton.setSize(100,20);
		addButton.setLocation(20,250);
		addButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				customer.getCart().add(pet);
				JOptionPane.showMessageDialog(null,"�ѳɹ����ӵ����ﳵ");
			}
		});
		jf.add(addButton);
		jf.setVisible(true);
	}
}
