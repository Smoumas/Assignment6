import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
/**
 * CartGUI���ṩ���ﳵ��GUI
 * @author user1
 *
 */
public class CartGUI {
	private JFrame jf;
	private Customer customer;
	private JLabel goodsLabel;
	private JLabel numbersLabel;
	private JLabel totalLabel;
	private int total;
	
	public CartGUI(Customer customer){
		this.customer=customer;
		jf=new JFrame("Cart");
		jf.setBounds(400,200,440,370);
		jf.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
		jf.setLayout(null);
		headInit();
		cartInit();
		jf.setVisible(true);
	}
	private void headInit(){
		goodsLabel=new JLabel("Goods");
		goodsLabel.setSize(100,20);
		goodsLabel.setLocation(20,20);
		jf.add(goodsLabel);
		numbersLabel=new JLabel("Number");
		numbersLabel.setSize(100,20);
		numbersLabel.setLocation(100,20);
		jf.add(numbersLabel);
		total=0;
		totalLabel=new JLabel("Total:$"+String.valueOf(total));
		totalLabel.setSize(100,20);
		totalLabel.setLocation(20,300);
		jf.add(totalLabel);
	}
	private void cartInit(){
		JButton buyAllButton=new JButton("Buy All");
		buyAllButton.setLocation(190,300);
		buyAllButton.setSize(100,20);
		jf.add(buyAllButton);
		JButton removeAllButton=new JButton("Remove All");
		removeAllButton.setLocation(310,300);
		removeAllButton.setSize(100,20);
		jf.add(removeAllButton);
		JPanel cartPanel=new JPanel();
		cartPanel.setLayout(null);
		cartPanel.setBounds(0,40,440,300);
		jf.add(cartPanel);
		Properties prop=customer.getCart().getCartContent();
		//���ﳵΪ����ʾnone
		if(prop==null||prop.size()==0){
			JLabel goodLabel=new JLabel("none");
			goodLabel.setSize(100,20);
			goodLabel.setLocation(20,1);
			JLabel numberLabel=new JLabel("none");
			numberLabel.setSize(100,20);
			numberLabel.setLocation(110,1);
			cartPanel.add(goodLabel);
			cartPanel.add(numberLabel);
			buyAllButton.setEnabled(false);
			removeAllButton.setEnabled(false);
			return;
		}
		//�����ﳵ�е�Pet�Լ���Ŀչʾ������ʾ������Ʒ���ܼ�total
		Set<Object> keys=prop.keySet();
		Iterator<Object>it=keys.iterator();
		int len=0;
		while(it.hasNext()){
			String good=(String) it.next();
			String number=prop.getProperty(good);
			JLabel goodLabel=new JLabel(good);
			goodLabel.setLocation(20,1+20*len);
			goodLabel.setSize(100,20);
			cartPanel.add(goodLabel);
			JLabel numberLabel=new JLabel(number);
			numberLabel.setLocation(110,1+20*len);
			numberLabel.setSize(100,20);
			cartPanel.add(numberLabel);
			total=total+Integer.parseInt(number);
			totalLabel.setText("Total:$"+total);
			JButton addButton=new JButton("+");
			JButton minusButton=new JButton("-");
			JButton buyButton=new JButton("Buy");
			JButton removeButton=new JButton("Remove");
			addButton.setLocation(170,1+20*len);
			addButton.setSize(42,18);
			minusButton.setLocation(220,1+20*len);
			minusButton.setSize(42,18);
			buyButton.setLocation(270,1+20*len);
			buyButton.setSize(60,18);
			removeButton.setLocation(335,1+20*len);
			removeButton.setSize(80,18);
			//���ﳵ�е�"+"
			addButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					//��number+1���������ӵ���Ŀ�洢��Ӳ����
					BufferedWriter bufw=null;
					try {
						String value=prop.getProperty(goodLabel.getText());
						value=String.valueOf(Integer.parseInt(value)+1);
						prop.setProperty(goodLabel.getText(),value);
						bufw=new BufferedWriter(new FileWriter(customer.getAccount()+"Cart.txt"));
						prop.store(bufw, null);
						numberLabel.setText(value);
						total++;
						totalLabel.setText("Total:$"+String.valueOf(total));
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}finally{
						try {
							bufw.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			});
			cartPanel.add(addButton);
			//���ﳵ�е�"-"
			minusButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					BufferedWriter bufw=null;
					try {
						String value=prop.getProperty(goodLabel.getText());
						value=String.valueOf(Integer.parseInt(value)-1);
						if(value.equals("0")){
							prop.remove(goodLabel.getText());
							cartPanel.remove(goodLabel);
							cartPanel.remove(numberLabel);
							cartPanel.remove(addButton);
							cartPanel.remove(minusButton);
							cartPanel.remove(buyButton);
							cartPanel.remove(removeButton);
							if(prop.size()==0){
								JLabel goodLabel=new JLabel("none");
								goodLabel.setSize(100,20);
								goodLabel.setLocation(20,1);
								JLabel numberLabel=new JLabel("none");
								numberLabel.setSize(100,20);
								numberLabel.setLocation(110,1);
								cartPanel.add(goodLabel);
								cartPanel.add(numberLabel);
								buyAllButton.setEnabled(false);
								removeAllButton.setEnabled(false);
							}
							jf.repaint();
						}
						else{
							prop.setProperty(goodLabel.getText(),value);
							numberLabel.setText(value);
							total--;
							totalLabel.setText("Total:$"+String.valueOf(total));
						}
						bufw=new BufferedWriter(new FileWriter(customer.getAccount()+"Cart.txt"));
						prop.store(bufw, null);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}finally{
						try {
							bufw.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			});
			cartPanel.add(minusButton);
			//���ﳵ��buy��ť�Ĺ���
			buyButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					BufferedWriter bufw=null;
					File file=new File(customer.getAccount()+"Bought.txt");
					Properties boughtProp=new Properties();
					try {
						prop.remove(goodLabel.getText());
						cartPanel.remove(goodLabel);
						cartPanel.remove(numberLabel);
						cartPanel.remove(addButton);
						cartPanel.remove(minusButton);
						cartPanel.remove(buyButton);
						cartPanel.remove(removeButton);
						if(prop.size()==0){
							JLabel goodLabel=new JLabel("none");
							goodLabel.setSize(100,20);
							goodLabel.setLocation(20,1);
							JLabel numberLabel=new JLabel("none");
							numberLabel.setSize(100,20);
							numberLabel.setLocation(110, 1);
							cartPanel.add(goodLabel);
							cartPanel.add(numberLabel);
							buyAllButton.setEnabled(false);
							removeAllButton.setEnabled(false);
						}
						total=total-1*Integer.parseInt(numberLabel.getText());
						totalLabel.setText("Total:$"+String.valueOf(total));
						jf.repaint();
						bufw=new BufferedWriter(new FileWriter(customer.getAccount()+"Cart.txt"));
						prop.store(bufw, null);
						boughtProp.setProperty(goodLabel.getText(),numberLabel.getText());
						if(!file.exists()){
							file.createNewFile();
						}else{
							BufferedReader bufr=new BufferedReader(new FileReader(file));
							boughtProp.load(bufr);
							if(boughtProp.containsKey(goodLabel.getText())){
								String number=boughtProp.getProperty(goodLabel.getText());
								number=String.valueOf(Integer.parseInt(number)+Integer.parseInt(numberLabel.getText()));
								boughtProp.setProperty(goodLabel.getText(),number);
							}else{
								boughtProp.setProperty(goodLabel.getText(),numberLabel.getText());
							}
						}
						bufw=new BufferedWriter(new FileWriter(file));
						boughtProp.store(bufw,null);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}finally{
						try {
							bufw.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			});
			cartPanel.add(buyButton);
			//���ﳵ��remove��ť�Ĺ���
			removeButton.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					// TODO Auto-generated method stub
					BufferedWriter bufw=null;
					try {
						prop.remove(goodLabel.getText());
						cartPanel.remove(goodLabel);
						cartPanel.remove(numberLabel);
						cartPanel.remove(addButton);
						cartPanel.remove(minusButton);
						cartPanel.remove(buyButton);
						cartPanel.remove(removeButton);
						if(prop.size()==0){
							JLabel goodLabel=new JLabel("none");
							goodLabel.setSize(100,20);
							goodLabel.setLocation(20,1);
							JLabel numberLabel=new JLabel("none");
							numberLabel.setSize(100,20);
							numberLabel.setLocation(110, 1);
							cartPanel.add(goodLabel);
							cartPanel.add(numberLabel);
							buyAllButton.setEnabled(false);
							removeAllButton.setEnabled(false);
						}
						total=total-1*Integer.parseInt(numberLabel.getText());
						totalLabel.setText("Total:$"+String.valueOf(total));
						jf.repaint();
						bufw=new BufferedWriter(new FileWriter(customer.getAccount()+"Cart.txt"));
						prop.store(bufw, null);
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}finally{
						try {
							bufw.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			});
			cartPanel.add(removeButton);
			buyAllButton.setEnabled(true);
			removeAllButton.setEnabled(true);
			len++;
		}
		//���ﳵ�е�BuyAll
		buyAllButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				Properties boughtProp=new Properties();
				File file=new File(customer.getAccount()+"Bought.txt");
				BufferedWriter bufw=null;
				if(!file.exists()){
					try {
						file.createNewFile();
						boughtProp=prop;
						bufw=new BufferedWriter(new FileWriter(file));
						boughtProp.store(bufw,null);
						jf.remove(cartPanel);
						JPanel cartPanel=new JPanel();
						cartPanel.setLayout(null);
						cartPanel.setBounds(0,40,440,300);
						jf.add(cartPanel);
						JLabel goodLabel=new JLabel("none");
						goodLabel.setSize(100,20);
						goodLabel.setLocation(20,1);
						JLabel numberLabel=new JLabel("none");
						numberLabel.setSize(100,20);
						numberLabel.setLocation(110,1);
						cartPanel.add(goodLabel);
						cartPanel.add(numberLabel);
						buyAllButton.setEnabled(false);
						removeAllButton.setEnabled(false);
						total=0;
						totalLabel.setText("Total:$0");
						jf.repaint();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}finally{
						try {
							bufw.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}else{
					BufferedReader bufr=null;
					try {
						bufr=new BufferedReader(new FileReader(file));
						boughtProp.load(bufr);
						Set<Object> keys=prop.keySet();
						Iterator<Object>it=keys.iterator();
						while(it.hasNext()){
							String key=(String)it.next();
							String number=prop.getProperty(key);
							if(boughtProp.containsKey(key))
								number=String.valueOf(Integer.parseInt(number)+Integer.parseInt(boughtProp.getProperty(key)));
							boughtProp.setProperty(key,number);
						}
						bufw=new BufferedWriter(new FileWriter(file));
						boughtProp.store(bufw, null);
						jf.remove(cartPanel);
						JPanel cartPanel=new JPanel();
						cartPanel.setLayout(null);
						cartPanel.setBounds(0,40,440,300);
						jf.add(cartPanel);
						JLabel goodLabel=new JLabel("none");
						goodLabel.setSize(100,20);
						goodLabel.setLocation(20,1);
						JLabel numberLabel=new JLabel("none");
						numberLabel.setSize(100,20);
						numberLabel.setLocation(110,1);
						cartPanel.add(goodLabel);
						cartPanel.add(numberLabel);
						buyAllButton.setEnabled(false);
						removeAllButton.setEnabled(false);
						totalLabel.setText("Total:$0");
						jf.repaint();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}finally{
						try {
							bufr.close();
							bufw.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
				prop.clear();
				BufferedWriter bufw2=null;
				try {
					bufw2=new BufferedWriter(new FileWriter(customer.getAccount()+"Cart.txt"));
					prop.store(bufw2,null);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}finally{
					try {
						bufw2.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		//���ﳵ�е�RemoveAll
		removeAllButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				prop.clear();
				BufferedWriter bufw=null;
				try {
					bufw=new BufferedWriter(new FileWriter(customer.getAccount()+"Cart.txt"));
					prop.store(bufw,null);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}finally{
					try {
						bufw.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				jf.remove(cartPanel);
				JPanel cartPanel=new JPanel();
				cartPanel.setLayout(null);
				cartPanel.setBounds(0,40,440,300);
				jf.add(cartPanel);
				JLabel goodLabel=new JLabel("none");
				goodLabel.setSize(100,20);
				goodLabel.setLocation(20,1);
				JLabel numberLabel=new JLabel("none");
				numberLabel.setSize(100,20);
				numberLabel.setLocation(110,1);
				cartPanel.add(goodLabel);
				cartPanel.add(numberLabel);
				buyAllButton.setEnabled(false);
				removeAllButton.setEnabled(false);
				total=0;
				totalLabel.setText("Total:$0");
				jf.repaint();
			}
		});
		return;
	}
}
