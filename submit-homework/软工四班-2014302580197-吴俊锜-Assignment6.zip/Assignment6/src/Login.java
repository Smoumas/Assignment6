import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
/**
 * Login���ṩ�û���¼����
 * @author user1
 *
 */
public class Login {
	private JFrame jf;
	private JLabel accountLabel;
	private JTextField accountText;
	private JLabel passwordLabel;
	private JPasswordField passwordText;
	private JButton loginButton;
	private JButton registerButton;
	
	public Login(){
		jf=new JFrame("Pet Sale Platform");
		jf.setBounds(480,200,400,240);
		jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		jf.setLayout(null);
		JLabel label=new JLabel("Please enter your account and password.");
		label.setSize(300,20);
		label.setLocation(50,40);
		jf.add(label);
		accountInit();
		passwordInit();
		loginButtonInit();
		registerButtonInit();
		jf.setVisible(true);
	}
	
	/**
	 * �˺�����ʼ��
	 */
	private void accountInit(){
		accountLabel=new JLabel("Account:");
		accountLabel.setSize(100,20);
		accountLabel.setLocation(50,78);
		jf.add(accountLabel);
		accountText=new JTextField();
		accountText.setSize(200,20);
		accountText.setLocation(120,80);
		//���ûس��¼�
		accountText.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e){
				int code=e.getKeyCode();
				if(code==KeyEvent.VK_ENTER){
					String userAccount=accountText.getText();
					String userPassword=new String(passwordText.getPassword());
					if(userAccount.equals("")){
						JOptionPane.showMessageDialog(null,"�������˺�");
						passwordText.setText("");
						return;
					}
					if(userPassword.equals("")){
						JOptionPane.showMessageDialog(null,"����������");
						accountText.setText("");
						return;
					}
					//��Ӳ�̶�ȡ�ļ������ļ�����������û���δע��
					File file=new File(userAccount+".txt");
					if(!file.exists()){
						JOptionPane.showMessageDialog(null,"���˻�������");
						accountText.setText("");
						passwordText.setText("");
						return;
					}
					try {
						Properties prop=new Properties();
						BufferedReader bufr=new BufferedReader(new FileReader(file));
						prop.load(bufr);
						String value=prop.getProperty("password");
						if(!value.equals(userPassword)){
							JOptionPane.showMessageDialog(null,"�������");
							accountText.setText("");
							passwordText.setText("");
							return;
						}
						//��֤�˺�������ȷ֮���û��ɹ���¼
						String ID=prop.getProperty("ID");
						String account=prop.getProperty("account");
						String password=prop.getProperty("password");
						String name=prop.getProperty("name");
						String sex=prop.getProperty("sex");
						String phone=prop.getProperty("phone");
						String address=prop.getProperty("address");
						String email=prop.getProperty("email");
						new Menu(new Customer(ID,account,password,name,sex,phone,address,email));
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		jf.add(accountText);
	}
	/**
	 * ��������ʼ��
	 */
	private void passwordInit(){
		passwordLabel=new JLabel("Password:");
		passwordLabel.setSize(100,20);
		passwordLabel.setLocation(45,120);
		jf.add(passwordLabel);
		passwordText=new JPasswordField();
		passwordText.setSize(200,20);
		passwordText.setLocation(120,120);
		//���ûس��¼�
		passwordText.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e){
				int code=e.getKeyCode();
				if(code==KeyEvent.VK_ENTER){
					String userAccount=accountText.getText();
					String userPassword=new String(passwordText.getPassword());
					if(userAccount.equals("")){
						JOptionPane.showMessageDialog(null,"�������˺�");
						passwordText.setText("");
						return;
					}
					if(userPassword.equals("")){
						JOptionPane.showMessageDialog(null,"����������");
						accountText.setText("");
						return;
					}
					File file=new File(userAccount+".txt");
					if(!file.exists()){
						JOptionPane.showMessageDialog(null,"���˻�������");
						accountText.setText("");
						passwordText.setText("");
						return;
					}
					BufferedReader bufr=null;
					try {
						Properties prop=new Properties();
						bufr=new BufferedReader(new FileReader(file));
						prop.load(bufr);
						String value=prop.getProperty("password");
						if(!value.equals(userPassword)){
							JOptionPane.showMessageDialog(null,"�������");
							accountText.setText("");
							passwordText.setText("");
							return;
						}
						String ID=prop.getProperty("ID");
						String account=prop.getProperty("account");
						String password=prop.getProperty("password");
						String name=prop.getProperty("name");
						String sex=prop.getProperty("sex");
						String phone=prop.getProperty("phone");
						String address=prop.getProperty("address");
						String email=prop.getProperty("email");
						new Menu(new Customer(ID,account,password,name,sex,phone,address,email));
						jf.dispose();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}finally{
						try {
							bufr.close();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			}
		});
		jf.add(passwordText);
	}
	
	/**
	 * ��½��ť��ʼ��
	 */
	private void loginButtonInit(){
		loginButton=new JButton("Login");
		loginButton.setSize(100,20);
		loginButton.setLocation(80,160);
		loginButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				String userAccount=accountText.getText();
				String userPassword=new String(passwordText.getPassword());
				if(userAccount.equals("")){
					JOptionPane.showMessageDialog(null,"�������˺�");
					passwordText.setText("");
					return;
				}
				if(userPassword.equals("")){
					JOptionPane.showMessageDialog(null,"����������");
					accountText.setText("");
					return;
				}
				File file=new File(userAccount+".txt");
				if(!file.exists()){
					JOptionPane.showMessageDialog(null,"���˻�������");
					accountText.setText("");
					passwordText.setText("");
					return;
				}
				try {
					Properties prop=new Properties();
					BufferedReader bufr=new BufferedReader(new FileReader(file));
					prop.load(bufr);
					String value=prop.getProperty("password");
					if(!value.equals(userPassword)){
						JOptionPane.showMessageDialog(null,"�������");
						accountText.setText("");
						passwordText.setText("");
						return;
					}
					String ID=prop.getProperty("ID");
					String account=prop.getProperty("account");
					String password=prop.getProperty("password");
					String name=prop.getProperty("name");
					String sex=prop.getProperty("sex");
					String phone=prop.getProperty("phone");
					String address=prop.getProperty("address");
					String email=prop.getProperty("email");
					new Menu(new Customer(ID,account,password,name,sex,phone,address,email));
					jf.dispose();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		jf.add(loginButton);
	}
	/**
	 * ע�ᰴť��ʼ����ע�Ṧ����Register���ṩ
	 */
	private void registerButtonInit(){
		registerButton=new JButton("Register");
		registerButton.setSize(100,20);
		registerButton.setLocation(200,160);
		registerButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				new Register();
			}
		});
		jf.add(registerButton);
	}
}
