import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
/**
 * customer�����������û�����
 * @author user1
 *
 */
public class Customer {
	private int id;
	private String ID;			//�û�ID
	private String account;		//�û��˺�
	private String password;	//�û�����
	private String name;		//�û�����
	private String sex;			//�û��Ա�
	private String phone;		//�û��绰����
	private String address;		//�û�סַ
	private String email;		//�û�Email
	public Customer(){
		return;
	}
	
	public Customer(String ID, String account, String password, String name, String sex, String phone, String address,String email) {
		super();
		this.ID = ID;
		this.account = account;
		this.password = password;
		this.name = name;
		this.sex = sex;
		this.phone = phone;
		this.address=address;
		this.email = email;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getID() {
		return ID;
	}
	public void setID(String iD) {
		ID = iD;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getPassword(){
		return password;
	}
	public void setPassword(String password){
		this.password=password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress(){
		return address;
	}
	public void setAddress(String address){
		this.address=address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Cart getCart(){
		return new Cart();
	}
	
	/**
	 * �ڲ���Cart�ṩ���ﳵ����
	 * @author user1
	 *
	 */
	class Cart{
		private String value="1";
		/**
		 * ��Pet���뵽���ﳵ��
		 * @param pet
		 */
		public void add(Pet pet){
			File file=new File(getAccount()+"Cart.txt");
			Properties prop=new Properties();
			if(!file.exists()){
				try {
					file.createNewFile();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				prop.setProperty(pet.getName(),value);
				FileOutputStream fos=null;
				try {
					fos=new FileOutputStream(file);
					prop.store(fos, null);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally{
					try {
						fos.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}else{
				BufferedReader bufr=null;
				BufferedWriter bufw=null;
				try {
					bufr=new BufferedReader(new FileReader(file));
					prop.load(bufr);
					String value=prop.getProperty(pet.getName());
					if(value==null){
						prop.setProperty(pet.getName(), this.value);
					}else{
						value=String.valueOf(Integer.parseInt(value)+1);
						prop.setProperty(pet.getName(), value);
					}
					bufw=new BufferedWriter(new FileWriter(file));
					prop.store(bufw, null);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}finally{
					try {
						bufw.close();
						bufr.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		/**
		 * ���ع��ﳵ�м����Pet����
		 * @return
		 */
		public Properties getCartContent(){
			File file=new File(getAccount()+"Cart.txt");
			if(!file.exists())
				return null;
			Properties prop=new Properties();
			BufferedReader bufr=null;
			try {
				bufr=new BufferedReader(new FileReader(file));
				prop.load(bufr);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				try {
					bufr.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return prop;
		}
	}
	
}
