import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.jdbc.Connection;
/**
 * Database������ݿ��л�ȡ12��Pet
 * @author user1
 *
 */
public class Database {
	
	private String url="jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	
	private Pet [] pets=new Pet[12];
	
	public Connection getConnection(){
		Connection conn=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			conn=(Connection) DriverManager.getConnection(url);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
	public void getPets(){
		Connection conn=null;
		Statement state=null;
		int index=0;
		try{
			conn=getConnection();
			state=conn.createStatement();
			ResultSet rs=state.executeQuery("select * from 2014302580197_pet");
			while(rs.next()){
				int id=Integer.parseInt(rs.getString(1));
				String name=rs.getString(2);
				String eat=rs.getString(3);
				String drink=rs.getString(4);
				String live=rs.getString(5);
				String hobby=rs.getString(6);
				pets[index]=new Pet(id,name,eat,drink,live,hobby);
				index++;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public Pet[] getPetArray(){
		return pets;
	}
}
