
public class Platform {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Login();
	}

}
